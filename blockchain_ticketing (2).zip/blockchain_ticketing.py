import hashlib
import datetime

# Step 1: Define a Block
class Block:
    def __init__(self, index, timestamp, event_name, ticket_id, buyer, previous_hash):
        self.index = index
        self.timestamp = timestamp
        self.event_name = event_name
        self.ticket_id = ticket_id
        self.buyer = buyer
        self.previous_hash = previous_hash
        self.hash = self.calculate_hash()

    # Step 2: Create unique hash for each block
    def calculate_hash(self):
        block_data = str(self.index) + str(self.timestamp) + self.event_name + self.ticket_id + self.buyer + self.previous_hash
        return hashlib.sha256(block_data.encode()).hexdigest()

    # Step 3: Display block info
    def display_block(self):
        print(f"\nBlock Index: {self.index}")
        print(f"Timestamp  : {self.timestamp}")
        print(f"Event Name : {self.event_name}")
        print(f"Ticket ID  : {self.ticket_id}")
        print(f"Buyer Name : {self.buyer}")
        print(f"Prev Hash  : {self.previous_hash}")
        print(f"Hash       : {self.hash}")


# Step 4: Define Blockchain
class Blockchain:
    def __init__(self):
        self.chain = [self.create_genesis_block()]

    # Genesis Block (first block of the chain)
    def create_genesis_block(self):
        return Block(0, str(datetime.datetime.now()), "Genesis Event", "0", "Admin", "0")

    # Get latest block
    def get_latest_block(self):
        return self.chain[-1]

    # Add new block to chain
    def add_block(self, event_name, ticket_id, buyer):
        latest_block = self.get_latest_block()
        new_block = Block(len(self.chain), str(datetime.datetime.now()), event_name, ticket_id, buyer, latest_block.hash)
        self.chain.append(new_block)

    # Verify if chain is valid
    def is_chain_valid(self):
        for i in range(1, len(self.chain)):
            current = self.chain[i]
            previous = self.chain[i - 1]

            if current.hash != current.calculate_hash():
                return False
            if current.previous_hash != previous.hash:
                return False
        return True

    # Display full blockchain
    def display_chain(self):
        for block in self.chain:
            block.display_block()


# Step 5: Simulate Ticket Transactions
ticket_chain = Blockchain()

# Adding 5 Events as blocks
ticket_chain.add_block("Dandiya Night", "TCK1001", "Khushi")
ticket_chain.add_block("Science Craft Show", "TCK1002", "Rohan")
ticket_chain.add_block("Circus Show", "TCK1003", "Ananya")
ticket_chain.add_block("Movie Premiere", "TCK1004", "Aarav")
ticket_chain.add_block("Food & Music Carnival", "TCK1005", "Simran")

# Step 6: Display Blockchain
print("🎟️ Event Ticket Blockchain Ledger 🎟️")
ticket_chain.display_chain()

# Step 7: Verify if chain is valid
print("\nBlockchain Valid:", ticket_chain.is_chain_valid())

# Step 8: Check Ticket Validity Function
def verify_ticket(ticket_id):
    for block in ticket_chain.chain:
        if block.ticket_id == ticket_id:
            print(f"\n✅ Ticket {ticket_id} is VALID for {block.event_name}, bought by {block.buyer}.")
            return
    print(f"\n❌ Ticket {ticket_id} is INVALID or FAKE.")

# Test Verification
verify_ticket("TCK1003")  # Existing
verify_ticket("TCK9999")  # Fake
